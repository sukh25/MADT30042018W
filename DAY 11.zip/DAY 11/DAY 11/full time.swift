//
//  full time.swift
//  DAY 11
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Cocoa

private class fulltime: STUDENT
{
    var subject: String?
    
    override  init() {
        self.subject = "Fulltime SUbject"
    }
    
    private func setSubject(subject: String)
    {
        self.subject = subject
    }
    
    //private func display()
    fileprivate func display()
    {
        //Not possible and not inherited
        //super.display()
        
        print("I am method of FullTime Class")
        super.display(message: "FILE PRIVATE")
    }
}

