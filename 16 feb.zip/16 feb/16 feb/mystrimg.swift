//
//  mystrimg.swift
//  16 feb
//
//  Created by MacStudent on 2018-02-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//singleton drsign pattern
//restrict use of class, declare static and private
//class will have only one obj

class MySingleotn {
    private static var instant = MySingleotn()
    private init(){}
    static func getInstant() -> MySingleotn{
        if instant != nil{
            return instant
        }
        else
        {
            instant = MySingleotn()
            return instant
        }
    }
    func getMyname() -> String {
        return "sukhman"
    }
}


