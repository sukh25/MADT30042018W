﻿
import Foundation

class TestA: IDisplay, IDisplayValue{
    var n1: Int = 20
    
    func displayValue() {
        print("Value of n1 : \(self.n1)")
    }
    
    func display() {
        print("Inside Class TestA")
    }
    
}

