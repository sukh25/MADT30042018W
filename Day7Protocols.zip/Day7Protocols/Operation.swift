﻿//

import Foundation


class Operation: Arithmetic{
    var oper: Character = "+"
    
    init(n1: Int, n2: Int, oper: Character){
        super.init(n1: n1, n2: n2)
        self.oper = oper
    }
    
    required init (n1: Int, n2: Int){
        super.init(n1: n1, n2: n2)
    }
    
    func calculate(){
        print("calling function \(self.n1) \(oper) \(self.n2)")
    }
}

