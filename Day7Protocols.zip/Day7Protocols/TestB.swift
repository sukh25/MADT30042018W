﻿import Foundation

class TestB: TestA{
    var n2: Int?
    
    override func display() {
        print("Inside Class B")
    }
    
    override func displayValue() {
        print("VAlue of n2 : \(n2!)")
    }
}

