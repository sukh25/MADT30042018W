//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//classes
class employee{
    var empid: Int?
    var empname: String?
    var basicpay: Double?
//initializers
    
    init(){
        self.empid=0
        self.empname="  "
        self.basicpay=0.0
    }
//parametrised initializer
    init(id: Int, nm: String, pay: Double){
        self.empid = id
        self.empname = nm
        self.basicpay = pay
    }
    func display(){
        print("employee id : ",self.empid!)
    print("employee name : ",self.empname!)
        print("basic pay : ",self.basicpay!)
}
    //deinitializer
    deinit{
        print("employee object deintialized")
    }
    
}

//self used for particular instance or refering  particular instance

var emp1 = employee()
emp1.empid = 101
emp1.empname = "sukhman"
emp1.basicpay = 5000
emp1.display()
var emp3 = employee()
emp3.display()
var emp4 = employee(id: 104,nm: "nav",pay: 3747.43)
emp4.display()

//inheriting  class from employee

class permanentEmployee : employee{
    var vacationWeeks : Int?
    
    //default intializer
     override init(){
super.init()
        self.vacationWeeks = 0
    
    }
    
    //parametrized intializer of sub class
    init(eid: Int, enm: String, epay: Double, weeks: Int){
        super.init(id: eid, nm: enm, pay: epay)
        self.vacationWeeks = weeks
    }
    override func display(){
        super.display()
        print("vacation Weeks : ",vacationWeeks!)
        
    }
}


var obj2 = permanentEmployee()
obj2.display()
obj2.vacationWeeks = 10
obj2.empid = 102
obj2.empname = "sukh"
obj2.basicpay = 4000


//only sub class will have over ridden methods
//with super, pass values to obj

var obj5 = permanentEmployee()
obj5.display()

var obj6 = permanentEmployee(eid: 106, enm: "navjot", epay: 2768.3, weeks: 1)
obj6.display()

//multilevel inheritence

class payroll : permanentEmployee{
    var netpay = Double?{
        get{
             var vw = self.vacationWeeks!
            if vw > 5
            {
                self.netpay! = self.basicpay! - 100
                
            }
            else
            {
                self.netpay! = self.bsaicpay!
            }
        }
    }
    override init()
    {
        super.init()
        //self.netpay = 0
    }
   override init(eid: Int, enm: String, epay: Double, weeks: Int) {
        super.init(id: eid, nm: enm, pay: epay)
      //self.netpay = 0
        }
    
    override func display(){
        super.display()
        //self.calculate()
      print("netpay : ", self,
            netpay)
    }
    
    
  /*  func calculate(){
    var vw = self.vacationWeeks
    if vw > 5
    {
    self.netpay! = self.basicpay! - 100
    
    }
    else
    {
    self.netpay! = self.bsaicpay!
    }
    */
}


    var obj7 = payroll(eid: 107, enm: "prabh", epay: 3464.4,weeks: 6)
//obj7.display()

//manipulating object array[]
var janpayroll = [payroll]()
let nofoemployees = 2

for i in 0..<2{
    janpayroll.append(eid: 107, enm: "ab", epay: 555.4, weeks: 7)

janpayroll[i].display()
}
