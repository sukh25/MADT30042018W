//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)
//to change terminator,if new line is not wanted
print("this is our string: \(str)",terminator: " ")
//use separator for separating multiple prompts
print("1","2","3","4","5",separator: "..")
//to assign new line
print("1","2","3",separator: "\n")

var n1=10
print("number 1: ",n1,"string: ",str)
var n2=20
print("number 2: ",n2)
var  sum = n1+n2
print (" sum is: ",sum)
print ("sum = ", n1+n2)
/*
n1 = "test"
print(n1 : ",n1)
*/
var a:Int = 10
print("a = ",a)

var greet:String = "good morning"
print("greetings : ",greet)
var b:Float = 2.5
print("b =",b)

var emoji = "😀"
print (" its a \(emoji) hour")
let pi = 3.14

print("pi= ",pi)

let mynum: Int? //optional
//mynum = 10
mynum = nil
if mynum != nil {
    print("mynum : ",mynum!)
}
    else
{
    print ("mynum is nil")
}

let possibleNumber = "123"
let convertNumber : Int?
convertNumber = Int(possibleNumber)

if convertNumber != nil{
    print("convertNumber" , convertNumber!)
    
}
else {
    print("convert number is nil")
}
//3 ... are necessary for condition
for i in 1..<5{

    print ("i = ",i)
}
let languages:[String]
languages=[ "English", "spanish", "french"]

for i in languages{
    
    print("languages: " , i)
    
}

let Sum:[Int]
Sum=[ 1 , 20]
for _ in Sum{
    
    print("Sum= ", 1+20)
}

var answer: Int = 1

for _ in 1...5{
    answer *= 5;
}
print("answer = ", answer)

var Interval: Int = 5
for i in stride( from:0, to: 50, by: Interval)
{
    print(i, " ", terminator: " ")
}

var itr1:Int = 0

while itr1 <= 5 {
    print("value : ", itr1)
    itr1 += 1
}

var j = 1

while(j <= 5)
{

    print( "value of j is \(j)")
    j = j + 1
}

j = 5
repeat{
    print( "repeat : ", j)
    j = j + 2
}while (j<=10)
var num: Int = 4
for _ in 1..<5{

    num *= 5;
}
print(num)
var num1 = 100

switch num1 {
case 100 :
print("value of num1 is 100")
fallthrough
case 10,15 :
print("value of num1 is either 10 or 15")
case 5 :
print( "value of num1 is 5")
default :
print("default case")
}
