//
//  main.swift
//  class activity day 10
//
//  Created by Gurkamaldeep Kaur on 2018-02-09.
//  Copyright © 2018 Sukhmandeep Kaur. All rights reserved.
//

import Foundation

print("Hello, World!")

var proceesrequest = requesttraffic()
do{
    try proceesrequest.decresedfine(trafficrule: "t120")
}catch trafficerror.overspeeding{
    print("your car is over speeded")
}catch  trafficerror.signalbrake{
    print("you break red signal")
}catch trafficerror.invalidlicence{
    print("your licence is invalid")
}catch trafficerror.rulebrake {
    print("you haven't wore belt")
}
    
catch{
    print("unexpected error")
}

