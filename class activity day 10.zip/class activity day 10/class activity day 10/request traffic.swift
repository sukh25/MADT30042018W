//
//  request traffic.swift
//  class activity day 10
//
//  Created by Gurkamaldeep Kaur on 2018-02-09.
//  Copyright © 2018 Sukhmandeep Kaur. All rights reserved.
//

import Foundation
class requesttraffic {
    var trafficrequest = [
        "t110" : drivinginformation(speed : 60,signalbrake:"red signal brake", passengerinfo : "passenger is in the car",licencetype :"valid", fine : 300,licenceissuedyear : 3),
        "t120" : drivinginformation(speed : 50,signalbrake : "red signal brake",passengerinfo : "passenger is in the car",licencetype :"invalid",fine : 200,licenceissuedyear : 2),
        "t130" : drivinginformation(speed : 70,signalbrake : "not brake at red signal",passengerinfo : "passenger is in the car",licencetype :"valid",fine : 400,licenceissuedyear : 4),
        "t140" : drivinginformation(speed : 60,signalbrake : "red signal brake",passengerinfo : "passenger is not in the car",licencetype :"valid",fine : 200,licenceissuedyear : 5),
        "t150" : drivinginformation(speed : 40,signalbrake:"red signal brake",passengerinfo : "passenger is not in the car",licencetype :"valid",fine : 200,licenceissuedyear : 5)
    ]
    
    
    func decresedfine(trafficrule traffic : String ) throws {
        
        guard let reqtraffic = trafficrequest[traffic] else {
            throw trafficerror.ineligible
        }
        guard reqtraffic.signalbrake == "red signal brake" && reqtraffic.licenceissuedyear >= 3 else{
            throw trafficerror.signalbrake
        }
        guard reqtraffic.speed <= 50 else{
            throw trafficerror.overspeeding
        }
        guard reqtraffic.passengerinfo == "passenger is in the car" else{
            throw trafficerror.rulebrake
        }
        guard reqtraffic.licencetype == "valid" else{
            throw trafficerror.invalidlicence
        }
        var decreasedfine = reqtraffic
        decreasedfine.fine -= 100
        print("your fine is \(decreasedfine.fine)")}
}
